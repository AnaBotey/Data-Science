    #RScript

#install.packages("tree")
#install.packages("rpart") 
#install.packages("rpart.plot")
#install.packages("partykit")
#install.packages("party")

library(tree)
library(rpart)
library(rpart.plot)
library(partykit)
library(party)

setwd("C:/Users/usuario/Desktop/tecnicas de clasificacione")

gender <- read.csv("http://www.biz.uiowa.edu/faculty/jledolter/DataMining/GenderDiscrimination.csv")

head(gender, 6) # comprobamos el encabezado de gender 
attach(gender)

## modelo a estimar Gender~ Experience + Salary
plot(gender$Gender)

# Semilla aleatoria

set.seed(124)

# Definimos una muestra aleatoria de aprendizaje del arbol que sera el 70% de los datos que # se tiene en el dataframe gender:

train <- sample(nrow(gender), 0.7*nrow(gender))

par(mfrow=c(1,2)) #dibujo conjunto

#mestra de entrenamiento (70%)
gender.train <- gender[train,]
plot(gender.train$Gender, main="muestra de entrenamiento")

#muestra de validacion (30%)
gender.validate <- gender[-train,]
plot(gender.validate$Gender, main="muestra de validacion")

arbol <- rpart(Gender~ ., data=gender.train,
               method="class",
               parms=list(split="information"))

print(arbol)

#summary(arbol)
plotcp(arbol)

prp(arbol, type = 1, extra = 104, fallen.leaves = TRUE, main="Decision Tree (sin podar)")

arbol$cptable

arbol.podado <- prune(arbol, cp=0.07291667)
arbol.podado
prp(arbol.podado, type = 2, extra = 104,
    fallen.leaves = TRUE, main="Decision Tree ")
plot(as.party(arbol.podado))

arbol.pred <- predict(arbol.podado, gender.validate, type="class")
arbol.perf <- table(gender.validate$Gender, arbol.pred, dnn=c("Actual", "Predicted"))
arbol.perf

#arbol basado en la inferencia condicional


fit.ctree <- ctree(Gender~., data=gender.train)

plot(fit.ctree, main="Conditional Inference Tree")

ctree.pred <- predict(fit.ctree, gender.validate, type="response")

ctree.perf <- table(gender.validate$Gender, ctree.pred,
                    dnn=c("Actual", "Predicted"))

ctree.perf

