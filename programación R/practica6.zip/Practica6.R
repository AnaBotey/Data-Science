#PROGRAMACI�N EN R	

	## dia 13/10/2017
	#===================

##M�todos de clasificacion para machine learning

rm=(lrst=ls())

	#  1. Cluster distancias
	#-------------------------


# Calcular las distancias para poder clasificar
#hay que tener en cuenta qu� distancia se va a utilizar, la m�s tradicional es la Euclidea, tanto para escalares, como para los vectores

a<- c(1, 1,6)
b<- c(4, 5,1)

#distancia de euclides generalizada
#se restan los vectores, se elevan al cuadrado y se suman y hacen la raiz cuadrada

sqrt(sum((a-b)^2))
#paquete multtest: golub
biocLite()
biocLite("multtest")

	#metodo del centroide
	#----------------------

library(multtest)
data(golub)
golub.gnames[1042,]

index<- grep("Cyclin", golub.gnames[,2])
index
golub.gnames[index, 2]

#calculo de distancias euclideas entre todos los genes cuyo descriptor contenga la plabra
# Cyclin

dist.cyclin<- dist(golub[index,], method = "euclidean") # la matriz es de 12*12
diam<- as.matrix(dist.cyclin)
rownames(diam)<- colnames(diam)
diam[1:5, 1:5]

#filtrado:: vamos a coger un gen y vamos a calcular la distancia de ese gen al rest0

biocLite("genefilter")
library("genefilter")
biocLite("ALL")
library("ALL")
data(ALL)

#buscar los genes de la base de datos ALL y nos mueste los m�s cercanos

closeto1389_at<- genefinder(ALL, "1389_at", 10, method="euclidean")
closeto1389_at[[1]]$indices
round(closeto1389_at[[1]]$dists, 1)

#10 nombres de genes m�s cercanos:

featureNames(ALL)[closeto1389_at[[1]]$indices]
str(closeto1389_at)
closeto1389_at[1]$'1389_at'
closeto1389_at[1]$'1389_at'$indices[1]

# Vamos a hacer un clistering que agrupe por clases:

# Hacemos clusters por el m�todo del centroide. Sevan realizando iteraciones agrupando
# los puntos seg�n la distancia m�nima entre el centroide.


names<- list(c("g1", "g2", "g3", "g4", "g5"), c("p1", "p2"))
names
sl.clus.dat<- matrix(c(1,1,1,1.1,3,2,3,2.3,5,5), ncol=2, byrow=TRUE, dimnames = names)
sl.clus.dat
plot(sl.clus.dat, lype = "n", xlim =c(0.6), ylim=c(0,6))

text(sl.clus.dat,labels = row.names(sl.clus.dat))
print(dist(sl.clus.dat,method="euclidean"), digits = 3)
sl.out<- hclust(dist(sl.clus.dat,method="euclidean"), method = "single")

plot(sl.out)


	#M�todo K-means
	#--------------

#En R, usamos la funci�n kmeans (data, k)

data <- rbind(matrix(rnorm(100,0,0.5), ncol = 2), matrix(rnorm(100,2,0.5), ncol = 2))
data
cl <- kmeans(data, 2)
cl
plot(clusdata, pch=as.numeric(gol.fac))
legend("topright", legend=c("ALL", "AML", pch=1:2))

?kmeans

plot(data, col=cl$cluster)
#cer-tama�o del dibujito del centro pch
points(cl$centers, col=1:2, pch=8, cex=2)

#------------------------
library("TeachingDemos")

put.points.demo()
#------------------------



	#2. An�lisis de componentes principales
	#---------------------------------------

eigen(cor(golub))$values[1:5]

data <- golub
p <- ncol(data)
n <- nrow(data)
nboot<-1000
eigenvalues <- array(dim=c(nboot,p))
for (i in 1:nboot){dat.star <- data[sample(1:n,replace=TRUE),]
eigenvalues[i,] <- eigen(cor(dat.star))$values}
eigen(cor(golub))$values[1:5]

for (j in 1:p) print(quantile(eigenvalues[,j],c(0.025,0.975)))
for (j in 1:5) cat(j,as.numeric(quantile(eigenvalues[,j],c(0.025,0.975))),"\n" )


########################16/10/2017###################################
#try http:// if https:// URLs are not supported
source("https://bioconductor.org/biocLite.R")
biocLite("multtest")

library(ROCR)
gol.true<- factor(golub.cl, levels=0:1, labels=c("TRUE", "FALSE"))
gol.pred<- factor(golub[1042,]>1.27, levels=c("TRUE", "FALSE"), labels=c("ALL", "notALL"))
table(gol.pred, gol.true)



gol.true<- factor(golub.cl, levels = 0:1, labels=c("TRUE", "FALSE"))
pred<- prediction(golub[1042,], gol.true)
pref<- performance(pred, "tpr", "fpr")
plot(pref)

set.seed(123);n<- 10; sigma<- 0.5
fac<- factor(c(rep(1, n), re







